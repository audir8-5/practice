import logging
import azure.functions as func
import json
import os
from azure.storage.blob import BlobServiceClient
import joblib

MODEL_PATH = "/tmp/global_weather_model.joblib"
MODEL_LOADED = None

def download_model():
    connect_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
    container_name = os.environ.get("MODEL_CONTAINER_NAME", "azureml")
    blob_name = os.environ.get("MODEL_BLOB_NAME", "global_weather_rf_tuned.joblib")

    if not connect_str:
        raise ValueError("Azure Storage connection string not found in environment variables.")

    blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    blob_client = blob_service_client.get_container_client(container_name).get_blob_client(blob_name)

    os.makedirs("/tmp", exist_ok=True)
    with open(MODEL_PATH, "wb") as f:
        f.write(blob_client.download_blob().readall())

def load_model():
    global MODEL_LOADED
    if MODEL_LOADED is None:
        if not os.path.exists(MODEL_PATH):
            download_model()
        MODEL_LOADED = joblib.load(MODEL_PATH)
    return MODEL_LOADED

def preprocess_input(data):
    features = {
        'lat': data.get('coord', {}).get('lat'),
        'lon': data.get('coord', {}).get('lon'),
        'temp': data.get('main', {}).get('temp'),
        'feels_like': data.get('main', {}).get('feels_like'),
        'humidity': data.get('main', {}).get('humidity'),
        'wind_speed': data.get('wind', {}).get('speed'),
        'clouds_all': data.get('clouds', {}).get('all'),
        'pressure': data.get('main', {}).get('pressure')
    }
    return [list(features.values())]

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("WeatherPredictV2 HTTP trigger function processed a request.")

    try:
        req_body = req.get_json()
        model = load_model()
        processed_input = preprocess_input(req_body)
        prediction = model.predict(processed_input)

        return func.HttpResponse(json.dumps({"predicted_temp": prediction[0]}), mimetype="application/json")

    except Exception as e:
        logging.error(f"Error: {e}")
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)